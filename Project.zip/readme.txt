Group6

Group Member:
- Chan Hon Fung  1155124829
- Lau Justin     1155126756
- Au Chun Hei    1155125607

Instruction:
- Upload the folder and "mysql-connector-java-5.1.47"
- Type the following code in CSE linux system
javac Project.java
- and run the programme by typing the code
java -cp .:mysql-connector-java-5.1.47.jar Project